# answers.py
# ----------

def q2():
    "*** YOUR CODE HERE ***"
    return 'a'