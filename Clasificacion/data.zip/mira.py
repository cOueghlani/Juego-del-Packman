# -- coding: UTF-8 --
# mira.py
# -------


# Mira implementation
import util
PRINT = True

class MiraClassifier:
    """
    Mira classifier.

    Note that the variable 'datum' in this code refers to a counter of features
    (not to a raw samples.Datum).
    """
    def __init__( self, legalLabels, max_iterations):
        self.legalLabels = legalLabels
        self.type = "mira"
        self.automaticTuning = False
        self.C = 0.001
        self.legalLabels = legalLabels
        self.max_iterations = max_iterations
        self.initializeWeightsToZero()

    def initializeWeightsToZero(self):
        "Resets the weights of each label to zero vectors"
        self.weights = {}
        for label in self.legalLabels:
            self.weights[label] = util.Counter() # this is the data-structure you should use

    def train(self, trainingData, trainingLabels, validationData, validationLabels):
        "Outside shell to call your method. Do not modify this method."

        self.features = trainingData[0].keys() # this could be useful for your code later...

        if (self.automaticTuning):
            Cgrid = [0.002, 0.004, 0.008]
        else:
            Cgrid = [self.C]

        return self.trainAndTune(trainingData, trainingLabels, validationData, validationLabels, Cgrid)

    def trainAndTune(self, trainingData, trainingLabels, validationData, validationLabels, Cgrid):
        """
        This method sets self.weights using MIRA.  Train the classifier for each value of C in Cgrid,
        then store the weights that give the best accuracy on the validationData.

        Use the provided self.weights[label] data structure so that
        the classify method works correctly. Also, recall that a
        datum is a counter from features to values for those features
        representing a vector of values.
        """
        "*** YOUR CODE HERE ***"
        myCounter = util.Counter()
        gridWeights = util.Counter()
        label = util.Counter()
        mySum = 0 


        #Recorremos la lista de valores constantes
        for c in Cgrid: 
            #Devuelve el maximo de iteraciones durante el train
            for a in range(self.max_iterations): 
                #Devuelve la longitud de los datos de train
                for b in range(len(trainingData)): 
                     #Guardamos las clases posibles para ser predecidas
                    for d in self.legalLabels: 
                        #Obtenemos la etiqueta de train de la clase que estamos evaluando realizando la multiplicacion
                        # de la matriz de pesos por el vector de variables
                        label[d] = trainingData[b].__mul__(self.weights[d]) 
                    if (trainingLabels[b] == label.argMax()):
                        pass
                    else:
                        maxLabel = label.argMax() #Asigna la mayor etiqueta 
                        countTwo = util.Counter()
                        trainData = trainingData[b]
                        trainLabel = trainingLabels[b]
                        weightCalc = (self.weights[maxLabel].__sub__(self.weights[trainLabel])).__mul__(trainData) + 1.0
                        multData = (2.0 / (trainData.__mul__(trainData)))
                    #Calcula los pesos
                        cal = weightCalc / multData 
                    #Devuelve el valor minimo
                        minArg = min(c, cal) 
                        #Por cada individuo del conjunto de entrenamiento
                        for e in trainingData[b].keys():
                            countTwo[e] = minArg * trainingData[b][e]
                        self.weights[label.argMax()].__sub__(countTwo)
                        self.weights[trainingLabels[b]].__radd__(countTwo)
            #Actualiza el contador          
            gridWeights[c] = self.weights 
            #Devuelve la longitud de los datos de validacion
            for f in range(len(validationData)): 
                for g in validationLabels:
                    label[g] = validationData[f].__mul__(self.weights[g]) #Obtiene label de validar
                if (validationLabels[f] != label.argMax()):
                    pass
                else:
                    #Lo anade a la suma si estamos en la maxlabel
                    mySum += 1    
            myCounter[c] = mySum #Actualzia contador
        #Actualiza los pesos aprendidos con el mejor valor de c  
        self.weights = gridWeights[myCounter.argMax()] 

    def classify(self, data ):
        """
        Classifies each datum as the label that most closely matches the prototype vector
        for that label.  See the project description for details.

        Recall that a datum is a util.counter...
        """
        guesses = []
        for datum in data:
            vectors = util.Counter()
            for l in self.legalLabels:
                vectors[l] = self.weights[l] * datum
            guesses.append(vectors.argMax())
        return guesses


